export const Setting = {
  SchoolName: "경북소프트웨어고등학교",
  SchoolDBName: "GBSW",
  SchoolFoodUrl:
    "https://school.gyo6.net/gbsw/ad/fm/foodmenu/selectFoodMenuView.do",
};
